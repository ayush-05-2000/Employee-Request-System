﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace WebApplication3.DTO
{
    public class ShiftDTO
    {
        public int shiftId { get; set; }
        public string shiftJob { get; set; }
        public DateTime shiftStartTime { get; set; }
        public DateTime shiftEndTime { get; set; }
    }
}
