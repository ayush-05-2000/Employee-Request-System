﻿namespace WebApplication3.DTO
{
    public class UserDTO
    {
        public string userEmail { get; set; }
        public string password { get; set; }
    }
}
