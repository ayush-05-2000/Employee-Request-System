﻿using WebApplication3.Data;
using WebApplication3.DTO;
using WebApplication3.Services;
using WebApplication3.DTO;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Text;

using Microsoft.AspNetCore.Mvc;
using PostgreSQL.Data;

namespace WebApplication3.Services
{ 
    public class UserService 
{
    private readonly AppDbContext _pg;
    // private readonly ITokenService _tokenService;
    public UserService(AppDbContext pg)
    {
        _pg = pg;

    }
    public string addUser(User user)
    {
        _pg.Users.Add(user);
        _pg.SaveChanges();
        return "user added";
    }

    public List<User> getUsers()
    {
        return _pg.Users.ToList();
    }


    public Dictionary<string, Object> Login(UserDTO _userData)
    {
        Dictionary<string, Object> res = new Dictionary<string, Object>();
        if (_userData != null && !string.IsNullOrEmpty(_userData.userEmail) && !string.IsNullOrEmpty(_userData.password))
        {
            var user = _pg.Users.FirstOrDefault(u => u.Email == _userData.userEmail && u.Password == _userData.password);
            if (user != null)
            {

                res.Add("user", user);

                res.Add("current time", DateTime.Now.ToString());
            }
        }
        return res;
    }
        
    }
}
   

