﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication3.DTO;

using PostgreSQL.Data;
using WebApplication3.Data;
using WebApplication3.DTO;
using WebApplication3.Services;

namespace WebApplication3.Services
{
    public class ShiftService 
    {
        private readonly AppDbContext _pg;
        public ShiftService(AppDbContext pg) { _pg = pg; }
        public Shift assignShift(Shift shift)
        {
            // Convert start and end times to UTC-free DateTime
            shift.shiftStartTime = shift.shiftStartTime.ToLocalTime();
            shift.shiftEndTime = shift.shiftEndTime.ToLocalTime();

            _pg.Shifts.Add(shift);
            _pg.SaveChanges();
            return shift;
        }

        public List<ShiftDTO> GetAvailableShifts()
        {
            List<Shift> shifts = _pg.Shifts.Where(shift => shift.user == null).ToList();
            List<ShiftDTO> res = new List<ShiftDTO>();
            foreach (Shift shift in shifts)
            {
                ShiftDTO shiftdto = new ShiftDTO();
                shiftdto.shiftId = shift.shiftId;
                shiftdto.shiftJob = shift.shiftJob;
                shiftdto.shiftStartTime = shift.shiftStartTime;
                shiftdto.shiftEndTime = shift.shiftEndTime;
                res.Add(shiftdto);
            }
            return res;
        }

        public List<Shift> getShifts()
        {
            return _pg.Shifts.Include(s => s.user).ToList();
        }

        public string postShift(Shift shift, [FromQuery(Name = "id")] int? id)
        {
            if (id.HasValue)
            {
                var user = _pg.Shifts.FirstOrDefault(u => u.userId == id.Value);

                if (user == null)
                {
                    return "user not found";
                }

               
                Console.WriteLine(shift.user);
                _pg.Shifts.Add(shift);
                _pg.SaveChanges();
                return "Shift added";
            }
            else
            {
                _pg.Shifts.Add(shift);
                _pg.SaveChanges();
                return "shift added";
            }
        }

        public string requestShift(Shift shift, [FromQuery(Name = "id")] int? id)
        {
            if (id.HasValue)
            {
                var user = _pg.Users.FirstOrDefault(u => u.UserId == id.Value);

                if (user == null)
                {
                    return "user not found";
                }

                shift.requested_user_id = id;
                _pg.Update(shift);
                _pg.SaveChanges();
                return "Request sent successfully";
            }
            else
            {
                return "Enter a valid userId";
            }
        }

        public List<ShiftDTO> GetShiftsAssignedToEmployee(int userId)
        {
            List<Shift> shifts = _pg.Shifts.Where(s => s.userId == userId).ToList();
            List<ShiftDTO> res = new List<ShiftDTO>();
            foreach (Shift shift in shifts)
            {
                ShiftDTO shiftdto = new ShiftDTO();
                shiftdto.shiftId = shift.shiftId;
                shiftdto.shiftJob = shift.shiftJob;
                shiftdto.shiftStartTime = shift.shiftStartTime;
                shiftdto.shiftEndTime = shift.shiftEndTime;
                res.Add(shiftdto);
            }
            return res;
        }
  
        public bool IsShiftOverlap(Shift requestedShift, int userId)
        {
            var assignedShifts = GetShiftsAssignedToEmployee(userId);

            foreach (var assignedShift in assignedShifts)
            {
                if ((requestedShift.shiftEndTime > assignedShift.shiftStartTime &&
                    requestedShift.shiftEndTime < assignedShift.shiftEndTime) ||
                    (requestedShift.shiftStartTime > assignedShift.shiftStartTime &&
                    requestedShift.shiftStartTime < assignedShift.shiftEndTime) ||
                    (requestedShift.shiftStartTime < assignedShift.shiftStartTime &&
                    requestedShift.shiftEndTime > assignedShift.shiftEndTime) ||
                    (requestedShift.shiftStartTime == assignedShift.shiftStartTime ||
                    requestedShift.shiftEndTime == assignedShift.shiftEndTime))
                {
                    // Shifts overlap
                    return true;
                }
            }
            return false;
        }
        public List<Shift> GetRequestedUserId()
        {
            return _pg.Shifts.Where(s => s.requested_user_id != 0).ToList();
        }
        
        private bool ShiftsOverlap(Shift newShift, Shift existingShift)
{
     return (newShift.shiftStartTime > existingShift.shiftStartTime && newShift.shiftStartTime < existingShift.shiftEndTime) ||
            (newShift.shiftEndTime > existingShift.shiftStartTime && newShift.shiftEndTime < existingShift.shiftEndTime) ||
            (newShift.shiftStartTime < existingShift.shiftStartTime && newShift.shiftEndTime > existingShift.shiftEndTime);
}


        public Shift ApproveShiftRequest(int shiftId)
        {
            try
            {
                var shift = _pg.Shifts.FirstOrDefault(s => s.shiftId == shiftId);

                if (shift == null)
                {
                    throw new Exception("Shift not found");
                }

                var requestedUserId = shift.requested_user_id;
                if (requestedUserId == 0)
                {
                    throw new Exception("No requested user for this shift");
                }

                var user = _pg.Users.FirstOrDefault(u => u.UserId == requestedUserId);
                if (user == null)
                {
                    throw new Exception($"User not found with id: {requestedUserId}");
                }
/*
                var userShifts = _pg.Shifts.Where(s => s.userId != null && s.userId == user.UserId);


                var overlappingShifts = userShifts.Any() && userShifts.Any(userShift => ShiftsOverlap(userShift, shift));

                if (overlappingShifts)
                {
                    throw new Exception("An overlapping shift request has already been approved");
                }*/

                // Check for past time approval
                if (shift.shiftStartTime <= DateTime.Now)
                {
                    throw new Exception("Cannot approve past time shifts");
                }


                // Update the shift
                shift.user = user;
                shift.requested_user_id = 0;

                _pg.SaveChanges();

                return shift;
            }
            catch (Exception ex)
            {
                
                Console.WriteLine($"An error occurred: {ex.Message}");
                return null; 
            }
        }


        public Shift DenyShiftRequest(int shiftId)
        {
            try
            {
                var shift = _pg.Shifts.FirstOrDefault(s => s.shiftId == shiftId);

                if (shift == null)
                {
                    throw new Exception("Shift not found");
                }

                var requestedUserId = shift.requested_user_id;
                if (requestedUserId == 0)
                {
                    throw new Exception("No requested user for this shift");
                }

                var user = _pg.Users.FirstOrDefault(u => u.UserId == requestedUserId);
                if (user == null)
                {
                    throw new Exception($"User not found with id: {requestedUserId}");
                }
                shift.user = null;
                shift.requested_user_id = 0;

                _pg.SaveChanges();

                return shift;
            }
            catch(Exception ex)
            
            {
                
                Console.WriteLine($"An error occurred: {ex.Message}");
                return null; 
            }

        }

        public List<Shift> GetApprovedRequests()
        {
            try
            {
                // Fetch all shifts where requested_user_id is not 0 (meaning a request exists)
                var requestedShifts = _pg.Shifts.Where(s => s.requested_user_id == 0).ToList();

                // Separate approved and denied requests based on user assignment
                var approvedRequests = requestedShifts.Where(s => s.userId != null).ToList();
                /*var deniedRequests = requestedShifts.Where(s => s.user == null).ToList();*/



                // Combine approved and denied requests into a single list
                var allRequests = approvedRequests.ToList();

                return allRequests;
            }
            catch (Exception ex)
            {
                // Log the exception or handle it gracefully
                Console.WriteLine($"An error occurred: {ex.Message}");
                return new List<Shift>(); // Return an empty list on error
            }
        }

        public List<Shift> GetDeniedRequests()
        {
            try
            {
                // Fetch all shifts where requested_user_id is not 0 (meaning a request exists)
                var requestedShifts = _pg.Shifts.Where(s => s.requested_user_id == 0).ToList();

                // Separate approved and denied requests based on user assignment
                /*var approvedRequests = requestedShifts.Where(s => s.user != null).ToList();*/
                var deniedRequests = requestedShifts.Where(s => s.userId == null).ToList();

                // Combine approved and denied requests into a single list
                var allRequests = deniedRequests.ToList();

                return allRequests;
            }
            catch (Exception ex)
            {
                // Log the exception or handle it gracefully
                Console.WriteLine($"An error occurred: {ex.Message}");
                return new List<Shift>(); // Return an empty list on error
            }
        }




    }


}


