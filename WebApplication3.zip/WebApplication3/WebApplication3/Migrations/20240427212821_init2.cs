﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication3.Migrations
{
    /// <inheritdoc />
    public partial class init2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_shift_table_Users_userId",
                table: "shift_table");

            migrationBuilder.RenameColumn(
                name: "userId",
                table: "shift_table",
                newName: "user_id");

            migrationBuilder.RenameIndex(
                name: "IX_shift_table_userId",
                table: "shift_table",
                newName: "IX_shift_table_user_id");

            migrationBuilder.AddForeignKey(
                name: "FK_shift_table_Users_user_id",
                table: "shift_table",
                column: "user_id",
                principalTable: "Users",
                principalColumn: "user_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_shift_table_Users_user_id",
                table: "shift_table");

            migrationBuilder.RenameColumn(
                name: "user_id",
                table: "shift_table",
                newName: "userId");

            migrationBuilder.RenameIndex(
                name: "IX_shift_table_user_id",
                table: "shift_table",
                newName: "IX_shift_table_userId");

            migrationBuilder.AddForeignKey(
                name: "FK_shift_table_Users_userId",
                table: "shift_table",
                column: "userId",
                principalTable: "Users",
                principalColumn: "user_id");
        }
    }
}
