﻿

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace WebApplication3.Data
{
    public class User
    {
        public enum UserRole
        {
            ADMIN,
            SITEMANAGER,
            EMPLOYEE
        }

        public enum Gender
        {
            MALE,
            FEMALE,
            OTHER
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("user_id")]
        public int UserId { get; set; }

        [Required]
        [Column("user_name")]
        public string UserName { get; set; } = string.Empty;

        [Required]
        [Column("user_email")]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [Column("user_password")]
        public string Password { get; set; } = string.Empty;

        [Required]
        [Column("user_role")]
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public UserRole userRole { get; set; }

        [Required]
        [Column("user_gender")]
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public Gender gender { get; set; }

        [Column("last_login_time_stamp")]
        public DateTime? LastLoginTimeStamp { get; set; }
    }
}