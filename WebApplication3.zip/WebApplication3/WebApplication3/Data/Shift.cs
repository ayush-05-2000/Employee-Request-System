﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using System.Globalization;
using System.Text.Json;
using WebApplication3.Data;

namespace WebApplication3.Data
{
    [Table("shift_table")]
    public class Shift
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("shift_id")]
        public int shiftId { get; set; }

        [Required(ErrorMessage = "Shift job description is required")]
        [Column("job")]
        public string shiftJob { get; set; }

        [Required(ErrorMessage = "Start time can't be null")]
        [Column("start_time", TypeName = "timestamp")]
        public DateTime shiftStartTime { get; set; }

        [Required(ErrorMessage = "End time can't be null")]
        [Column("end_time", TypeName = "timestamp")]
        public DateTime shiftEndTime { get; set; }

        [Column("requested_user_id")]
        public int? requested_user_id { get; set; }

        [ForeignKey("user_id")]
        
        public int? userId { get; set; }
        public User? user { get; set; }


    }
}
 
    
    
