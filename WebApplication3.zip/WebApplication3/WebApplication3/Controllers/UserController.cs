﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.DTO;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Data;

using WebApplication3.Services;

namespace WebApplication3.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class UserController : Controller
    {
        private readonly UserService _userService;
        public UserController(UserService userService)
        {
            this._userService = userService;
        }


        // [Authorize]
        [HttpGet]
        [Route("/users")]
        public List<User> getUsers()
        {
            return _userService.getUsers();
        }

        [HttpPost]
        public string addUser(User user)
        {
            return _userService.addUser(user);
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("/login")]
        public IActionResult Login(UserDTO user)
        {

            Dictionary<string, Object> res = new Dictionary<string, object>();
            res = _userService.Login(user);
            if (res.Count() == 0)
            {
                IActionResult response = Unauthorized();
                return response;
            }
            return Ok(res);
        }
    }
}
