﻿using WebApplication3.Data;
using WebApplication3.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using WebApplication3.DTO;


namespace WebApplication3.Controllers
{
    [ApiController]
    [Route("/api/[controller]")]
    public class ShiftController : Controller
    {
        private readonly ShiftService _shiftService;
        public ShiftController(ShiftService shiftService)
        {
            this._shiftService = shiftService;
        }



        [HttpGet]
        public List<Shift> getShifts()
        {
            return _shiftService.getShifts();
        }

        [HttpPost]
        [Route("linkshift")]
        public string postShift(Shift shift, [FromQuery(Name = "id")] int? id)
        {
            return _shiftService.postShift(shift, id);
        }

        [HttpPost]
        [Route("assignshift")]
        public Shift assignShift(Shift shift)
        {
            return _shiftService.assignShift(shift);
        }

        [HttpGet]
        [Route("availableshifts")]
        public List<ShiftDTO> GetAvailableShifts()
        {
            return _shiftService.GetAvailableShifts();
        }


        [HttpPost]
        [Route("requestshift")]
        public string requestShift(Shift shift, [FromQuery(Name = "id")] int? id)
        {
            return _shiftService.requestShift(shift, id);
        }

        [HttpGet]
        [Route("getshiftsassignedtoemployee")]
        public List<ShiftDTO> GetShiftsAssignedToEmployee(int userId)
        {
            return _shiftService.GetShiftsAssignedToEmployee(userId);
        }

        [HttpGet("requested")]
        public ActionResult<List<Shift>> GetRequestedUserId()
        {
            return _shiftService.GetRequestedUserId();
        }

        /*[HttpPost]
        [Route("approve/{id}")]
        public IActionResult ApproveShiftRequest(Shift shift)
        {
            return Ok(_shiftService.ApproveShiftRequest(shift));
        }*/
        [HttpPost]
        [Route("approve/{id}")]
        public Shift ApproveShiftRequest(int id)
        {
            return _shiftService.ApproveShiftRequest(id);
        }

        [HttpPost]
        [Route("deny/{id}")]
        public Shift DenyShiftRequest(int id)
        {
            return _shiftService.DenyShiftRequest(id);
        }

        [HttpGet]
        [Route("historyapprove")]
        public List<Shift> GetApprovedHistory()
        {
            return _shiftService.GetApprovedRequests();
        }
        [HttpGet]
        [Route("historydeny")]
        public List<Shift> GetDeniedHistory()
        {
            return _shiftService.GetDeniedRequests();
        }



    }
}